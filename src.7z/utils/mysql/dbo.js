

function dbo(){}

module.exports = dbo;