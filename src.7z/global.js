var globalVariables = {
    server : {
        port : 8099
    },
    mySql : {
        address : '192.168.221.130',
        port : 3016,
        schema : 'mmc'
    },
    varibales : {
        uploadCache : 'E:\\node\\files\\cache',
        staticFilesPath : 'E:\\node\\files\\static'
    }
};

module.exports = globalVariables;